<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', '2023.its-espas_db' );

/** Database username */
define( 'DB_USER', '2023.its-espas_a' );

/** Database password */
define( 'DB_PASSWORD', 'd93T6c6sgstFxS9H-jE9' );

/** Database hostname */
define( 'DB_HOST', 'localhost:3306' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '20&#dXPy:tG56x7:L0(mE6x0qK(iB%1_9v3hfgm(wW5I@7kL2+1m1G[o5O84A0P;');
define('SECURE_AUTH_KEY', 'N7W6;lEuU/Pc9T5p~c2U(+Xw0:3Ak9~NgD|s@908oycmbS1seA#N0RBJ42G9+%fn');
define('LOGGED_IN_KEY', 'l(!_K-M96L2|UE*X97G90j77vfz*zK#IM65)r:z3Y(u%heF2F+se9!D4bYZP]Q4(');
define('NONCE_KEY', 'si18ST:/L+qJw@y0iU[6@!Ulinx&ifmHufP8D7E7sSV2T4~W~5A7@dNDuw)5/A0I');
define('AUTH_SALT', ')X&mUJ73b8Sq[77W4Do]4qlv/6xne~CX;2s(ZYrLEu4B)g*7FQ5/n9O[3bC;;k[#');
define('SECURE_AUTH_SALT', 'tp0zf4LH3LRP7P#Gm06O*g75@wX8a&4~b89da1WR7Kw;V2b%XmCc;d6X-i*&74|]');
define('LOGGED_IN_SALT', 'M[~7M2f9h8FsOzs*VTgp27-*&35rY(rNI5t1Y-0LwHud1%f#Sx-I2#7PbI~R[C)@');
define('NONCE_SALT', '1EJ023KH9X@&az+on+0vg5E%cS0om7i/03AIVh~lI*8U!+4J4;4Gmcgh#9UvZ;5G');


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_its_';


/* Add any custom values between this line and the "stop editing" line. */

define('WP_ALLOW_MULTISITE', true);
/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
